class Abstract:
    #초기화
    def __init__(self):
        pass
    #naver.py에서 사용됨
    def getCreateTableQuery(self, tableName):
        """
        :param  tableName : string
        :return           : string
        매체별 TABLE CREATE QUERY 반환
        """
        createQuery = ""
        return createQuery
    #naver.py에서 사용됨
    def getInsertQuery(self, tableNm):
        """
        :param tableNm  : string
        :return         : string
        매체별 INSERT QUERY 반환
        """
        return ""