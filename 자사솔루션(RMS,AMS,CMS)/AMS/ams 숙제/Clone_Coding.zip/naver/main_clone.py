#import 영역
from datetime import datetime
import json 
import sys, argparse, time
from main import processCheckArgv json
sys.payth.append(".")
from media.multiprocess import MediaMultiProcess
from media.mediashwitcher import MediaSwitcher
from media.helpers import helper as mainHelper
from media.models import history
from media.conifg import Config
from recollecting import Recollecting

"매체별 multiprocessing main"
def mediaProcess():
    start = time.time() #시작 시간 저장 : 
    helper = mainHelper.Helper() #공통 헬퍼 클래스
    processMessage, startDate, targetDate, status = list(['SUCESS',helper.getNowDateString(),None,True])#포르세스 로그 메시지, 프로세스시작시간, 수집일자, 상태초기 설정
    config = Config() #설정정보 관련클래스
    media, targetDate, updateCheck = list(processCheckArgv(helper, config)) #명령어 체크 (아래 함수 있음)
    HistoryModel = history.HistoryModel() # 히스토리모델 클래스
    mediaKR = historyModel.getmediaCode(config.getAllConfig()[media]['name_kr']) #매체 한글명
    historyId = historyModel.insertMediahistory(targetDate.strfttime('%Y-%m-%d'),mediaKR) # history ID

    try : #정상적으로 실행되는 경우
        multiProcess = MediaMultiProcess() # 병렬처리
        processer = MediaSwitcher().getMedia(media, targetDate, historyId, updateCheck) # 함수의 안자들을 이용하여 매체별로 분기
        targetList = processer.getTargetList() # 병렬처리 진행할 매체 리스트들
        multiProcess.startMultiProcess(targetList, processer, {}) # 병렬처리 진행
        processMessage = processer.resultProcess(historyId) #작업 중 내용
        if len(processMessage) > 0: # 작업중 내용이 있으면 출력하고
            processMessage = "\r\n".join(processMessage)
        else : #작업 중 내용이 없으면 성공
            processMessage : "SUCCESS"
        endDate = helper.getMediaProcess(historyId, endDate, processMessage)#프로세스 테이블 업데이트
    except Exception as e : #에러일경우
        import traceback # import
        processMessage = traceback.format_exc() #에러메세지
        print(processMessage) # 출력
        print(e)
        endDate = helper.getNowDateString() # 현재 일시 반환 (끝 날짜)
        HistoryModel.updateMediaProcess(historyId, endDate, processMessage)



"명령어 인자체크함수"
def processCheckArgv(helper, conifg):
    allConfig = config.getAllConfig() # 설정파일 (Config) Class
    parser = argparse.ArgumentParser()
    parser.add_argument("media", help="target media - {}".format(' , '.join(allConfig.keys())))     #매체명
    parser.add_argument("-d", "--date", help="target date format YYYY-MM-DD example) 2022-07-25")   # 수집일자
    parser.add_argument("-ud", "--update-check", help= "advertiser media history update check - true or false") # 테이블 업데이트(t_advertiser_media_management,t_advertiser_media_history )
    args=parser.parse_args()
    if args.date is not None : #날짜가 있으면
        targetDate = helper.getDateFromString(args.date).date()
    else : #날짜가 없으면
        targetDate = helper.getYesterdayDate()
    if args.update_check == 'ture' #default 는 true
        # update_check이 false면 updateCheck도 False
        updateCheck = False
    media = args.media
    return [media, targetDate, updateCheck] #배열형태로 리턴




if __name__=='__main' : # Main일 떄 아래 함수 실행
    mediaProcess()
    