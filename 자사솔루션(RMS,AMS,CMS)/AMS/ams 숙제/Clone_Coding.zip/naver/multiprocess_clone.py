import multiprocessing,time
from media.config import Config
class MediaMultiProcess:
    " multiprocessing class.각 매체 별 API 호출을 위한 mutiprocessing 함수 및 Config 파일의 내용을 호출하는 함수"
    config = None
    def __init__(self): # Config 파일에서 multiprocessing에 관련된 설정을 가져옴 ( config.getMultiProcessConfig() )
        config = Config() # config CLASS
        self.config = config.getMultiProcessConfig() 
        # getMultiProcessConfig는 self.getGeneralConfig()['multiprocess'] 를 반환 
        # getGeneralConfig는 self.config['general']를 반환

    # multiprocessing 시작
    def startMultiProcess(self,targetList,targetClass,shareDict):
        process = self.getConfig()['count'] # 현재 시스템에서 사용 할 프로세스 개수
        # 병렬처리
        pool = multiprocessing.Pool(processes=process)  # 멀티프로세스 pool 객체생성 해서 
        pool.map(targetClass.execute,targetList) # pool의 map메소드를 활용해서  targetClass.execute 와 targetList를 전달 
        pool.close() #  리소스 낭비를 방지하기 위해 close호출
        pool.join() #   작업 완료 대기를 위해 join함수호출
    def getConfig(self):
        return self.Config