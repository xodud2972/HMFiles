from email.errors import InvalidDateDefect
import time,json,re,sys
import time, json, re, sys
from pymysql import NULL
from media.api.naverapi import NaverApi as MediaApi
from media.process.abstract.multiprocess import MultiProcess as AbstractProcess
from media.models.database.naver import Naver as MediaRowReport

class Naver(AbstractProcess):
    processNamve = 'naver' # naver
    noneData = '-'
    
    "초기화 함수"
    def __init__(self, targetDate=None, mediaHistoryId = None, managementUpdateCheck=False) : 
        super().__init__(targetDate, mediaHistoryId, managementUpdateCheck) #초기화
        self.masterReportClient,self.stateReportClient,self.stateReportClient = [None, None, Noen] #maset, stateClicent 처리
        authConfig = self.getAuthCOnfig() #네이버 인증 설정 가져오기
        self.mediaAPi = MediaAPi[authCOnfig['appkey'], authConfig['appSecret'], authConfig['customerId']) # medaiApi
        self.masterReportClient = self.getMedaiApi().getMasetReportClient()
        self.stateReportClient = self.getMediaApi().getstatReportApi()
    
    "병렬처리"
    def _getTargetList(self): 
        authConfig = self.getAuthConfig() # 네이버 인증 설정 가져오기
        helper = self.getHelper()   # 헬퍼 클래스 생성
        masterPath = helper.relationJoinPath('file', self.processName, 'report', 'master') # Base_Path + path
        # downloadReportData함수 = 리포트 데이터 다운로드함수 (아래쪽에 함수 있음) 
        self.downloadReportData('Account', authConfig['customerId'], authConfig['customer'])# 리포트 데이터 다운
        """ checkAccountData함수는계정 리스트 조회중 오류 발생시 예외상황 발생 시키기 및 프로그램 종료
            @param path 계정 리스트 파일 경로
            joinPath는 targetDir 내부 파일 mergeFile 로 묶음"""
        accountList = helper.checkAccountData(helper.joinPath(masterPath, 'Accoutn','{}.tsv'.format(authConfig['customerId'])))
        targetDateString = self.getTargetDate().strfttime('%Y-%m-%d') #tagetDate문자형태
        accoutnData = []
        managementModel = self.getManagmentModel(False)
        # getMediaLastChangeHistory함수는 매체별로 광고주의 최신상태 변경 이력 값(이관,피이관 등등) 가져오기
        lastHistoryData = managementModel.getMediaLastChangeHistory(self.getMediaCode()).copy()
        inTransferAdvertiser = []
        inTransferHistory = []
        mediaCode = self.getMediaCode() # 매체코드
        totalAdvertiserData = helper.getTotalAdvertiserData(self.getRmsDb()) #  t_customer 정보 가져오기
        # 매체별로 t_media_mapping_latest 테이블의 정보 가져오기
        lastMatchingInfo = helper.getLastMatchingDataByMNm(self.getMediaConfig()['m_nm'],self.getDefalut()) 
        for key,account in enumerate(accountList): #계정리스트 개수만큼 반복
            matchingId = account[1]
            inDate = accoutn[5]:[10]
            accoutnData.append({
                'matching_id' : matchingID,
                'ind_date' : InvalidDateDefect
            })
        if matchingId not in lastHistoryData : #신규이면
            emSeq, csSeq, cstype, division, team = [None, None, None, None, None] # None
            "getMatchinginfo함수는 매체별로 matching id 로 매핑된 emSeq,csSeq,csNm,csType,division,team,csTypeNew1,csTypeNew2 정보 가져오는 함수"
            emSeq, csSeq, csNm, csType, divisoin, team, csTypeNew1, csTypeNew2 = helper.getMatchinginfo(self.processName, matchingId, self.getDfulatId(), self.getRmsDb()) #매체별 matching id 로 매핑된 emmSeq,csSeq,csNm,csType,division,team,csTypeNew1,csTypeNew2 정보 가져오기
            "t_advertiser_media_management등록"            
            inTransferAdvertiser.append([
                mediaCode,matchingId, self.getDataTableName(account[0]),csSeq,csType,
                matchingId, accoutn[0], accoutnd[2], None, json.sumps(account)
            ])
            "t_advertiser_media_history 등록"
            inTransferHistory.append([
                mediaCode, mathcingId, mediaCode, mathcingId, emSeq, inDate
            ])
            accountList[key].append[None]
        else : #신규가아니면
            "t_advertiser_media_history data"
            accountList[key].append(lastHistoryData[matchingId])
            "lastHistroyData가 남아있다면 == 피이관"
            lastHistoryData.pop(matchingId)
        self.bulkInTransferProcess(inTransferAdvertiser, inTracnsferHIstory, managementModel) # 매체별로 이관계정을 묶음처리한다 (management.py에 있음)
        self.outTransferProcess(lastHistoryData) # 매체별로 피이관 계정을 묶음처리한다. (management.py에 있음)
        self.getHistoryModel().insertAdvertiserTodayTarget(targerDateString, self.getPRocessId(), self.getMediaCode(), accoundData,'mathcing_id','in_date')
        return accoutnList #계정리스트 반환

    #실행부
    def _excute(self, target, shareData = None):
        helper = self.getHelper() #헬퍼클래스 생성
        startedDate = helper.getNowDateString() # 시작날짜 
        historyModle = self.getHistoryModel() # HISTORY MODEL CLASS 반환 HISTORY LOG 관련
        targetDAte = self.getTargetDate() # targetDate
        customerID = target[0] # customerId
        customer = target[1] #customer
        self.loadHistoryId(customer) #계정별 히스토리 아이디 가져오기   
        historyId = self.getHistoryID()  # 매체 계정별 history id
        try:
            # downloadReportData함수는 아래쪽에 있는 리포트 데이터 다운로드 함수이다.
            stateResult = self.downloadReportData('AD', customerId, customer, targetDate.strftime("%Y%m%d"), 'state')
            advertiserInfo = {
                'matching_Id': target[1],
                'main_id':target[1],
                'sub_ID':target[0],
                'name':target[2],
                'beforeData': target[6]
            }
            if stateResult:
                # downloadReportData함수는 아래쪽에 있는 리포트 데이터 다운로드 함수이다
                self.downloadReportData('AD_CONVESION', customerId, customer, taregtDate.stfrtime("%Y%m%d"), 'state')
                "downloadTargetData 함수는 마스터 정보 다운로드 Campaign, Adgroup, Keyword (아래쪽에 있음)"
                self.downloadTargetData(customerID,customer)
                # dataResultProccess함수는 데이터 형태 가공 (아래쪽에 있다) - groupName,campaignType,campaignName,conversionCnt.....stateDate RETRUN
                bindData = self.dataResultProccess(customerId,customer)
                EndDate = helper.getNowDatestring()
                # updateAdvertiserData함수는 광고주 히스토리 정보를 업데이트하는 함수임
                historyModel.updateAdvertiserData(historyID, startedDate, endDate, len(bindData))
                self.databaseProcess(customerId, customer, bindData, advertiserInfo)
            else:
                "휴먼체크30일"
                if advertiserInfo['beforData'] is not None:
                    emSeq, csSeq, csNm, csType, division, team, CsTypeNew1, CSTypeNew2 = self.getMatchingInfo(customer)
                    advertiserInfo['em_seq'] = emSeq
                    hasData = False
                    managementModel = self.getManagmentModel() 
                    # updateAdvertiserStatusHistory함수는 MANAGEMENT,HISTORY 상태이력을 업데이트하는 함수(managemanet.py)
                    managementModel.updateAdvertiserStatusHistory(self.getMediaCode(), advertiserInfo, hasData, advertiserInfo['beforeData']) 
        except Exception as e:# 오류 반환
            import traceback # import
            historyModel.insertHistoryMessagge(historyId, traceback.format_exc()) # t_advertiser_history_message에 메시지 입력
        return True # True 반환

    
    def makeResultReprotFile(self,customerId,customer, advertiserInfo): # 리포트 파일 생성 - 현재 파일에선 사용되지 않음
        helper = self.getHelper() # 헬퍼 클래스 생성
        targetDateString = self.getTargetDate().strftime("%Y-%m-%d") # targetDate문자형태
        dataTableNm = self.getDatatableName(customerId) #datatableNm
        emSeq, csSeq, CsNm, CsType, division, team,csTypeNew1,csTypeNew2 = self.getMatchingInfo(customer) # em,cs 정보를 matchingId로 가져오기
        mediaCOde = self.getMediaCode() # mediaCode 메체코드
        # redultData 가져오기
        resultData = self.getDB().fetchAll("""
        select '{}','{}','{}','{}','{}','{}','{}','{}','{}','{}',advertiser_login_id, campaign_type,
        CAST(sum(impression_cnt) as SIGNED ),CAST(sum(click_cnt) as SIGNED ),CAST(sum(cost) as SIGNED )
        ,CAST(sum(conversion_cnt) as SIGNED ),CAST(sum(conversion_amnt) as SIGNED )
        from {} where pay_date=%s group by campaign_type
        """.format(targetDateString,mediaCode,emSeq,division,team,csSeq,csNm,csType,CsTypeNew1,CSTypeNew2,dataTableNm),[targetDateStirng])
        if advertiserInfo['beforeData'] is not None: # advertiserInfo['beforeData']가 None이면 advertiserInfo['em_seq'] 재설정
            advertiserInfo['em_seq']=em_seq
            hasData = self.hasDataCheckByCost(resultData)  # 매체 계정별 리포트 데이터 광고 비용 체크 - 휴면 30일 확인용
            managementModel = self.getManagementModel()  
            # updateAdvertiserStatusHistory함수는 MANAGEMENT,HISTORY 상태이력을 업데이트하는 함수(managemanet.py)
            managementModel.updateAdvertiserStatusHistory(mediaCode,advertiserInfo,hasData,advertiserInfo['beforeData']) 
        # checkDir함수는 DIRECTORY EXISTS 점검 CREATE - TRUE 시 없을시 생성하는 함수이다.
        helper.checkDIr(helper.relationJoinpath('file',self.processName,'report','result')) # 폴더 유무 점검 없을시 생성
        # reletionJoinPath함수 BASE_PATH + path 가져오기 (helper.py)
        helper.writeCSVFileData(helper.reletionJoinPath('file',self.processName,'report','result',dataTableNm),resultData) # CSV 파일 입력 후 저장

    def makeKeywordFilterFile(self, customerID, customer): ## 리포트 키워드 필터 파일생성 - 현재 파일에선 사용되지 않는다.
        mediaDb = self.getDB() 
        helper = self.getHelper() # 헬퍼 클래스 생성
        targetDateString = self.getTargetDate().strtfime("%Y-%m-%d") # targetDate문자형태
        dataTableNm = self.getDataTableName(customerId) #dateTableNm
        emSeq, csSeq, csNm, csType, division, team,csTypeNew1,csTypeNew2 = self.getMatchingInfo(customer) # em,cs 정보 matchingId로 가져오기
        # resultData
        resultData = mediaDB.fetchAll("""
        SELECT '{}','{}','{}','{}','{}','{}','{}','{}','{}',
        campaign_type, campaign_id, campaign, group_id, {tableName}.group, keyword_id, keyword, CAST(SUM(impression_cnt) AS SIGNED) AS impression_cnt, CAST(SUM(click_cnt) AS SIGNED) AS click_cnt,
        CAST(SUM(cost) AS SIGNED) AS cost, IF(sum(click_cnt)>0 && SUM(impression_cnt)>0,ROUND((sum(click_cnt)/sum(impression_cnt)),2),0) AS ctr 
        ,CAST(sum(conversion_cnt) as SIGNED ),CAST(sum(conversion_amnt) as SIGNED )
        FROM {} WHERE pay_date=%s and not keyword='-' GROUP BY campaign_id, campaign_type, group_id, keyword_id HAVING (impression_cnt >=100 or click_cnt>=5 or cost>=10000)
        """.format(targetDateString, emSeq, division, team, csSeq, csType,csTypeNew1,csTypeNew2, customer,
            dataTableNm, tableName = dataTableNm),[targetDateString])
        # resultData있으면
        if resultData:
            longData = mediaDb.fetchAll("""
            SELECT '{}', '{}', '{}', campaign_type, 'filter', count(keyword) FROM 
            (SELECT pay_date, CAST(SUM(impression_cnt) AS SIGNED) AS impression_cnt, 
            CAST(SUM(click_cnt) AS SIGNED) AS click_cnt, CAST(SUM(cost) AS SIGNED) AS cost, 
            campaign_id, campaign, campaign_type, group_id, {tableName}.group, keyword_id, keyword, CAST(sum(conversion_cnt) as SIGNED ),CAST(sum(conversion_amnt) as SIGNED )
            FROM {} WHERE pay_date=%s and not keyword='-' 
            GROUP BY campaign_id, campaign_type, group_id, keyword_id
            HAVING (impression_cnt >=100 or click_cnt>=5 or cost>=10000)) AS a
            """.format(targetDateString,self.processName, customer, dataTableNm, tableName = dataTableNM),[targetDateString])
            # checkDir함수는 DIRECTORY EXISTS 점검 CREATE - TRUE 시 없을시 생성하는 함수이다.
            helper.checkDir(helper.relationJoinPath('file', 'keyword', self.processName, 'filter', 'long')) # 폴더 유무 점검 없을시 생성
            # reletionJoinPath함수 BASE_PATH + path 가져오기 (helper.py)
            helper.writeCsvFileData(helper.relationJoinPath('file', 'keyword', self.processName, 'filter', 'log', dataTableNm),logData) # CSV 파일 입력 후 저장
            # checkDir함수는 DIRECTORY EXISTS 점검 CREATE - TRUE 시 없을시 생성하는 함수이다.
        helper.checkDir(helper.relationJoinmPath('file', 'keyword', self.proccessName, 'fillter', 'result')) # 폴더 유무 점검 없을시 생성
        # reletionJoinPath함수 BASE_PATH + path 가져오기 (helper.py)
        helper.writeCsvFileData( helper.relationJoinPath('file', 'keyword', self.processName, 'filter', 'result', dataTableNm),resultData)# CSV 파일 입력 후 저장

    def bindConversionData(self,conversionData): # 전환 데이터 추가
        " 전환 데이터 추가 "
        bindData = {
            'keyword': {},
            'ad': {}
        }
        for row in conversionData: # conversionData 배열 개수만큼 반복
            keywordId = row[4]
            adID = row[5]
            mediaCode = row[7]
            rowData = {
                'conversion_cnt': row[11],
                'conversion_ant': row[12]
            }
            if self.noneData != keywordId:
                if mediaCode not in bindData['keyword']:
                    bindData['keyword'][mediaCode] = {}
                if adId not in bindData['keyword'][mediaCode]:
                    bindData['keyword'][mediaCode][adId] = {}
                bindData['keyword'][mediaCode][adId][keywordId] = rowData
            else:
                if mediaCode not in bindData['ad']:
                    bindData['ad'][mediaCode] = {}
                bindData['ad'][mediaCode][adId] = rowData
        return bindData

    def dataResultProccess(self,customerId,customerName): # 데이터 형태 가공 stateData에 모아서 리턴
        " 데이터 형태 가공 "
        keywordData, campaignData, groupData, stateData, conversionData = list(self.getTargetFileData(customerId))
        targetDate = self.getTargetDate().strftime("%Y-%m-%d") # targetDate
        bindConversionData = self.bindConversionData(conversionData) # 전환 데이터 추가
        # enumerate(stateData) 배열 개수 만큼 
        # enumerate : 인자풀기 (for 돌릴 수 있도록)
        for key, row in enumerate(stateData):
            stateData[key][0] = targetDate
            keywordId = row[4]
            mediaCode = row[7]
            adId = row[5]
            keyword = self.noneData if keywordId not in keywordData else keywordData[row[4]]
            groupName = self.noneData if row[3] not in groupData else groupData[row[3]]
            campaignName = self.noneData if row[2] not in campaingData else campaignData[row[2]]['campaign_name']
            campaignType = 0 if row[2] not in campainData else campaignData[row[2]]['campaign_type']
            conversionCnt = 0
            conversionAnt = 0
            if keywordId == self.noneData:
                if mediaCode in bindConversionData['ad'] and adId in bindConversionData['ad'][mediaCode]:
                    conversionCnt = bindConverdionData['ad'][mediaCode][adId]['conversion_cnt']
                    conversionAmnt = bindconversionData['ad'][mediaCode][adID]['conversion_amnt']
                    bindConversionData['ad'][mediaCode].pop(adId)
                    if len(bindConversionData['ad'][mediaCode]) == 0:
                        bindConversionData['ad'].pop(mediaCode)
            else :
                if mediaCode in bindConversionData['keyword'] \
                        and adId in bindConversionData['keyword'][mediaCode]\
                        and keywordId in bindConversionData['keyword'][mediaCode][adId]:
                    conversionCnt = bindConversionData['keyword'][mediaCode][adId][keywordId]['conversion_cnt']
                    conversionAmnt = bindConversionData['keyWord'][mediaCode][adId][keywordId]['conversion_amnt']
                    bindConversionData['keyword'][mediaCode][adId].pop(keywordId)
                    if len(bindConversionData['keyword'][mediaCode][adId]) == 0:
                        bindConversionData['keyword'][mediaCode].pop(adId)
                    if len(bindConversionData['keyword'][meidacode]) == 0:
                        bindConversiondata['keyword'].pop(mediaCode)
            stateData[key].insert(5, keyword)
            stateData[key].insert(4, groupName)
            stateData[key].insert(3, campaignType)
            stateData[key].insert(2, campaignName)
            stateData[key].insert(1, customerName)
            stateData[key].append(conversionCnt)
            stateData[key].append(conversionAnt)
        return stateData

    #downloadTargetData 함수는 마스터 정보 다운로드 (Campaign, Adgroup, Keyword 3가지) 
    def downloadTargetData(self,customerId,customer): 
        self.downloadReportData('Campaign', customerId, customer) # 리포트 데이터 다운로드
        self.downloadReportData('AdGroup', customerId, customer) # 리포트 데이터 다운로드
        self.downloadReportData('Keyword', customerId, customer) # 리포트 데이터 다운로드

    def getTargetFileData(self,customerId): # 생성된 파일의 데이터 가져오기
        helper = self.getHelper() #헬퍼클래스생성
        masterPath = helper.relationJoinPath('file',self.processName,'report','master') #  BASE_PATH + path 가져오기
        statePath = helper.relationJoinPath('file',self.proccessName,'report','state')
        keywordFile = helper.joinPath(masterPath, 'Keyword', "{}.tsv".format(customerId)) # path 가져오기
        campaignFile = helper.joinPath(masterPath, 'Campaign', "{}.tsv".format(customerId))
        groupFile = helper.joinPath(masterPath, 'Adgroup', "{}.tsv".format(customerID))
        stateFile = helper.joinPath(statepath, 'AD', "{}.tsv".format(customerId))
        conversionFile = helper.joinPath(statePath, 'AD_CONVERSION', "{}.tsv".format(customerid))
        keywordData = {} if helper.isFile(keywordFile) == False else helper.bindCsvFileByKey({2: 3}, keywordFile) # isFile 함수는 파일 존재하는지 확인
        campaignData = {} if helper.isFile(campaignFile) == False else helper.bindTsvFileByKey({1: {'campaign_name': 2, 'campaign_type': 3}}, campaignFile)
        groupData = {} if helper.isFile(groupFile) == False else helper.bindTsvFileByKey({1: 3}, groupFile)
        stateData = {} if helper.isFile(stateFile) == False else helper.getTsvFileData(stateFile)
        conversionData = {} if helper.isFile(conversionFile) == False else helper.getTsvFileData(conversionFile)
        return [keywordData,campainData,groupData,stateData,conversionData]

    def downloadReportCheckData(self,apiType):
        apiClient = self.getMasterReportClient() # self.masterReportClient 를 리턴시킴 (아래에 함수 있음)
        reportIDKey = 'id'
        helper = self.getHelper() # 헬퍼클래스 생성
        filePATH = helper.relationJoinPath('file',self.processName,'report','master') # 파일 PATH
        if apiType != 'master':
            apiClient = self.getStateReportClient() # self.stateReprotClient를 리턴시킴 (아래에 함수 있음)
            reportIdKey = 'reportJobId'
            filePath = helper.relationJoinPath('file',self.processName,'report','state') #  BASE_PATH + path 가져오기
        return [ apiClient, reportIdKey, filePath ]

    def downloadReportData(self, type, customerId, customer, date=None, apiType='master'): # 리포트 데이터 다운로드
        helper = self.getHelper() # 헬퍼클래스 생성
        returnResult = False
        apiClient,reportIdKey,filePath = list(self.downloadReportChckData(apiType)) 
        apiClient.setCustomerId(customerId)
        createResult = self.creatReport(apiClient,type,date)
        if createResult == False or reportIdkey not in createResult:
            self.getHistoryModel().insertHistoryMessagge(self.getHistoryId()
                                                    ,"{} REPORT CREATE ERROR CUSTOMER ID : {} ,CUSTOMER : {}, RESULT : {}".format(type,customerId,customer,creatResult))
            return False
        createResult = self.checkReport(type,apiClient,reportIdKey,customerId,customer,createResult) #  아래쪽에 함수 있음
        createStatus = createResult['status']
        if createStatus == 'BUILT': # 리포트 생성중이면
            helper.checkDir("{}/{}".format(filePath,type)) # 디렉토리를 확인
            self.reportDownlaod(apiClient,createResult['downloadUrl'],helper.joinPath(filePath,type,'{}.tsv'.format(customerId))) # 리포트 tsv 다운로드 생성
            returnResult = True
        if createStatus in [400, 403]: # 파일 생성 제한 오류 100 개
            self.getHistoryModel().insertHistoryMessage(self.getHistoryId(),"{} ERROR CUSTOMER ID : {} ,CUSTOMER : {}, MESSAGE : {}".format(type,customerId, customer,
                                                                                       createResult['detail']))
        elif createStatus in ['NONE', 'EROR']: # none 이나 error이면 리포트를 삭제한다.
            self.deleteReport(apiCient, createResult[reportIdKey])
        else: # 그 밖이면 리포트를 삭제한다.
            self.deleteReport(apiCient, createResult[reportIdKey])
        return returnResult

    def checkReport(self,type,apiClient,reportIdKey,customerId,customer,createResult): # 리포트 확인
        reportId = createResult[reportIdKey]
        while True: # 무한루프 
            if createResult['status'] in ['BUILT', 'NONE', 'ERROR', 400, 403]: # 조건에 부합하면 while문을 break한다.
                break
            time.sleep(1)
            try:
                createResult = apiClient.get(reportId)
            except Exception as e: #오류발생시 에러 insert
                self.getHistoryModel().insertHistoryMessagge(self.getHistoryId()
                                                        ,"{} REPORT CREATE ERROR CUSTOMER ID : {} ,CUSTUMER : {}, MESSAGE : {}".format(type, customerId,customer,e))
                continue
        return createResult

    def bindKeywordById(self,file): # tsv파일에서 keywordId 가져오기
        data = self.getHelper().getTSVFileData(file)
        bindData = {}
        for row in data:
            keywordId = row[2]
            keywordName = row[3]
            bindData[keywordId] = keywordName
        return bindData

    def deleteReport(self,api, id): # 리포트 삭제
        result = self.getHelper().limitedTryCall(api.delete,reportId=id)
        if result==False:
            self.getHistoryModel().insertHistoryMessage(self.getHistoryId()
                                                        , "DELETE REPORT FAIL : {}".format(id))
        return result

    def createReport(self,api, type, date=None): # 리포트 생성
        result = self.getHelper().limitedTryCalls(api.create,reportType=type,statDt=date)
        if result==False:
            self.getHistoryModel().insertHistoryMessage(self.getHistoryId()
                                                        , "CREATE REPORT FAIL : {} {}".format(type,date))
        return result

    def reportDownload(self,api, url, path): # 리포트 다운로드
        result = self.getHelper().limitedTryCalls(api.download,url=url,file=path)
        if result==False:
            self.getHistoryModle().insertHistoryMessage(self.getHistoryId()
                                                        , "REPORT DOWNLOAD ERROR - URL : {} ,PATH : {}".format(
                                                                 url, path))
        return result

    def getMediaRowReport(self):
        return MediaRowReport()

    def getMasterReportClient(self):
        return self.masterReportClient

    def getStateReportClient(self):
        return self.stateReprotClient

    # 네이버 인증 설정 가져오기
    def getAuthConfig():
        """
        :return: {}
        네이버 인증 설정 가져오기
        """
        return self.getMediaConfig()['auth'][0]
