from media.helpers.helper import Helper
from media.db import Db
from media.models import history,report
from media.models.advertiser.media.management import Management
from media.modles.halfMonth import HalfMonth
import json, time, sys
class AbstracttProcess: #추상클래스
    # 초기화  NONE처리
    def __init__(self,targetDate=None, processId=None, managementUpdateChck=False):
        self.mediaApi, self.outTransferData, self.matchingInfo = [None,{},{}] # api 객체, 피이관 데이터, 담당자 정보
        self.db,self.defaultDb,self.rmsDb,self.devDb,self.liveDb = [None,None,None,None,None] # 각 미디어 디비, hm 디비, rms 디비, 개발 서버 db
        self.historyModel,self.mediaCode,self.reportModel,self.historyId = [None,None,None] # history모델, 매체코드, 리포트모델, historyID
        self.managememtModel = None
        self.processMessages = []
        self.processId = processID
        self.helper = Helper()
        self.config = self.getHelper().getConfig()
        self.managementUpdateCheck = managementUpdateCheck
        if targetDate is None:
            self.targetDate = self.getHelper().getYesterdayDate()
        else:
            self.targetDate = targetDate
    def getTargetList(self): #처리 대상 가져오기
        return self._getTargetList()
    def _getTargetList(self): 
        return []
    def execute(self,advertiser,shareData=None): # 대상 처리 
        return self._execute(advertiser,shareData)
    def _execute(self,advertiser,shareData=None): 
        return True
    def resultProccess(self,processId,bindData=None,hasKeyword=True): # 리포트 입력 및 로그 관리 추가
        self.processId = processId
        helper = self.getHelper() # 공통헬퍼클래스
        targetDate = self.getTargetDate() # 타겟데이트
        targetDateString = targetDate.strtfime('%Y-%m-%d') #타겟데이트 문자형태
        db = self.getDB() # DB 클래스생성
        baseReportPath = helper.relationJoinPath('file',self.processName) #  FILE에 BASE_PATH + path 가져오기
        helper.checkDIr(baseReportPath) #  DIRECTORY 유효 점검 CREATE - TRUE 시 없을시 생성
        self.insertReportFile() # 리포트 디비 입력
        if hasKeyword: #키워드가 있으면
            self.insertKeywordFile() # 키워드 필터 리포트 파일 입력
        fromWeek = helper.getBeforeDate(targetDate.weekday(),targetDate) # getBeforeDate는 days 수 만큼의 이전일자 가져오기
        toWeek = helper.getAferDate(6,fromWeek) # getAferDate는  days 수 만큼의 이후일자 가져오기
        historyModel = self.getHistoryModel() # historyModel클래스생성
        mediaCode = self.getMediaCode() # 매체코드
        historyModel.insertMappingSunmary(targetDateString,mediaCode,db) # t_advertiser_mapping_summary 입력 입력
        historyModel.insertHistorySummary(targetDateString,mediaCode,self.processId,db) #t_advertiser_history_summary 입력
        historyModel.insertResultCheck(targetDateString,fromWeek.strftime('%Y-%m-%d'),toWeek.strftime('%Y-%m-%d'),targetDate.strftime('%Y-%m'),mediaCode,db)#t_advertiser_result_check 입력
        HalfMonth(self.getTargetDate(), self.getHelper(), self.getDefaultDb(), mediaCode).insertHalfMonthByMedia()
        helper.removeDir(helper.relationJoinPath('file',self.processName)) #  DIRTORY 제거
        if hasKeyword:
            self.keywordCountCheck('filter') # 키ㅣ워드 수량 점검
            helper.removeDir(helper.relationJoinPath('file','keyword',self.processName)) #  DIRTORY 제거
        return self.processMessages
    def getManagementModel(self,shareDb=True): 
        if self.managementModel is None:
            dbName = self.getMediaConfig()['db']['db_name']
            if shareDb:
                self.managementModel = Management(self.getTargetDate(),dbName,self.getManagementupdateCheck(),self.getHelper(),self.getDb(),self.getDefaultDB())
            else:
                self.managementModel = Management(self.getTargetDate(), dbName,self.getManagementUpdateCheck())
        return self.managementModel
    def getMatchingInfo(self,matchingId): # em,cs 정보 matchingId로 가져오기
        matchingId = str(matchingID)
        if matchingId not in self.matchingInfo: # matchingId가 없으면
            helper = self.getHelper() #헬퍼클래스 생성
            self.matchingInfo[matchingId] = list(helper.getMatchingInfo(self.processName,matchingId,self.getDefaultDb(),self.getRmsDB()))
        return self.matchingInfo[matchingId]
    def keywordCountCheck(self,type='all'): # 키워드 수량 점검
        defaultDb = self.getDefaultDb() # db생성
        targetDate = self.getTargetDate() # targetDate 생성
        reportModel = self.getReportModel()# reportModel생성
        historyModel = self.getHistoryModel() # historyModel 생성
        resultData = reportModel.keywordCountCheck(targetDate.strftime("%Y-%m-%d"),self.processName,defaultDb,type)
        if len(resultData['advertiser']) > 0:
            for data in resultData['advertiser']:
                # insertHistoryMessageByMatchingId함수는 matchingId 기준 t_advertiser_history_message 메시지 입력
                historyModel.insertHistoryMessageByMatchingId(self.processId,data['matching_id'],data['message'])
        if len(resultData['media']) > 0:
            for message in resultData['media']:
                self.processMessages.append(message)
    def insertReportFile(self): # 리포트 디비 입력
        helper = self.getHelper() # 헬퍼클래스생성
        reportDir = helper.relationJoinPath('file', self.processName, 'report') #  FILE에 BASE_PATH + path 가져오기
        resultFile = helper.joinPath(reportDir, 'report_Result.csv') #  path 가져오기
        targetDir = helper.joinPath(reportDir, 'result')
        helper.mergeFileFromDir(resultFile, targetDir) # targetDir 내부 파일 mergeFile 로 묶음
        defaultDb = self.getDefaultDb() # db생성
        mediaCode = self.getMediaCode() # 매체코드생성
        targetDate = self.getTargetDate() # targetDate 생성
        fromWeek = helper.getBeforeDate(targetDate.weekday(),targetDate)
        toWeek = helper.getAfterDate(6,fromWeek)
        reportModle = self.getReportModel()
        # t_report_daily 테이블 입력 (report.py) , t_report_week 테이블 입력, t_daily_month 테이블 입력
        reportModel.insertDailyReport(resultFile,targetDate.strftime('%Y-%m-%d'),mediaCode,defaultDb) \
            .insertWeekReport(fromWeek.strftime('%Y-%m-%d'), toWeek.strtfime('%Y-%m-%d'),mediaCode,defaultDb) \
            .insertMonthReprot(targetDate.strftime('%Y-%m'), targetDate.strftime('%Y-%m-%d'),
                               targetDate.strftime('%Y-%m-') + str(helper.getLastDayFromDate(targetDate))
                               ,mediaCode,defaultDb)
    def refreshWeekMonthData(self): # 주,월 리포트 데이터 제거 후 재 입력
        helper = self.getHelper() # 헬퍼클래스생성
        defaultDb = self.getDefaultDb() # db생성
        mediaCode = self.getMediaCode() # 매체코드생성
        targetDate = self.getTargetDate()# targetDate 생성
        fromWeek = helper.getBeforDate(targetDate.WeekDay(),targetDate)
        toWeek = helper.getAfterDate(6,fromWeek)
        reportModel = self.getRepotModel() # reportModel클래스생성
        # t_report_week 테이블 입력,  t_daily_month 테이블 입력
        reportModel.insertWeekReport(fromWeek.strftime('%Y-%m-%d'), toWeek.strftime('%Y-%m-%d'),mediaCode,defaultDb) \
            .insertMonthReport(targetDate.strftime('%Y-%m-%d'), targetDate.strftime('%Y-%m-%d'),
                               targetDate.strftime('%Y-%m-%d') + str(helper.getLastDayFromDate(targetDate))
                               ,mediaCode,defaultDb)
    def refreshWeekMonthKeyWordFilter(self): # 주,월 키워드 리포트 데이터 제거 후 재 입력
        helper = self.getHelper()# 헬퍼클래스생성
        reportModel = self.getReportModel()# reportModel클래스생성
        targetDate = self.getTargetDate()# targetDate 생성
        fromWeek = helper.getBeforeDate(targetDate.weekday(),targetDate)
        toWeek = helper.getAfterDate(6,fromWeek)
        mediaCode = self.getMediacode()# 매체코드생성
        #  t_keyword_filter_week입력, t_keyword_filter_month 입력
        reportModel.insertWeekKeyWordFilter(fromWeek.strftime('%Y-%m-%d'), toWeek.strftime('%Y-%m-%d'), mediaCode)\
            .insertMonthKeywordFillter(targetDate.strftime('%Y-%m-%d'), targetDate.strftime('%Y-%m-%d'),
                                          targetDate.strftime('%Y-%m-%d') + str(helper.getLastDayFromDate(targetDate)), mediaCode)

    def insertKeywordFile(self): # 키워드 필터 리포트 파일 입력
        helper = self.getHelper() # 헬퍼클래스생성
        targetDate = self.getTargetDate() # targetDate 생성
        fromWeek = helper.getBeforeDate(targetDate.weekday(), targetDate) 
        toWeek = helper.getAfterDate(6, fromWeek)
        self.insertKeywordFilterFile(targetDate,fromWeek,toWeek) # # 키워드 필터 리포트 파일 입력

    def insertKeywordFilterFile(self,targetDate,fromWeek,toWeek): # 키워드 필터 리포트 파일 입력
        helper = self.getHelper()  # 헬퍼클래스생성
        reportModel = self.getReportModel() # reportModel클래스생성
        filterReportDir = helper.relationJoinPath('file', 'keyword', self.proccessName, 'filter') #  BASE_PATH + path 가져오기
        if helper.isDir(filterReportDir) == False:
            return
        filterResultFile = helper.joinPath(filterReportDir, 'keyword_result_filter.csv')
        filterTargetDir = helper.joinPath(filterReportDir, 'result')
        logFilterresultFile = helper.joinPath(filterReportDir, 'keyword_result_log.csv')
        logFilterTargetDir = helper.joinPath(filterReportDir, 'log')
        if helper.isDir(filterTargetDir) and len(helper.listDir(filterTargetDir)) > 0: # isDir는 DIRECTORY 점검
            helper.mergeFilterFromDir(filterResultFile, filterTargetDir) # targetDir 내부 파일 mergeFile 로 묶음
            # t_keyword_filter_daily 입력, t_keyword_filter_week입력, insertMonthKeywordFilter
            reportModel.insertDailyKeywordFilter(filterResultFile, self.mediaCode) \
                .insertWeekKeywordFilter(fromWeek.strftime('%Y-%m-%d'), toWeek.strftime('%Y-%m-%d'),  self.mediaCode) \
                .insertMonthKeywordFilter(targetDate.strftime('%Y-%m'), targetDate.strftime('%Y-%m-01'),
                                          targetDate.strftime('%Y-%m-') + str(helper.getLastDayFromDate(targetDate)),  self.mediaCode)
        else:
            self.processMessages.append('KEYWORD REPORT IS EMPTY')
        if helper.isDir(logFilterTargetDir) and len(helper.listDir(logFilterTargetDir)) > 0:  # isDir는 DIRECTORY 점검
            helper.mergeFileFromDir(logFilterResultFile, logFilterTargetDir) # targetDir 내부 파일 mergeFile 로 묶음
            self.getHistoryModel().insertKeywordCount(logFilterResultFile) # t_media_keyword_count 입력
        else:
            self.processMessages.append('LOG FILTER COUNT IS EMPTY')
    def getProcessId(self): # #프로세스 ID 가져오기
        return self.processId

    def dataToJson(self,data): #LIST -> JOSN
        return json.dumps(data)

    def closeResourve(self): # 사용 자원 반환
        self.closeHistory()
        self.closeManagement()
        self.rmsDb=None
        self.devDB=None
        self.liveDb=None
        self.db=None

    def dataBaseProcess(self, customerId, customer, processData, advertiserInfo, hasKeyword=True): # 매체 계정별 디비 입력 처리
        historyModel = self.getHistoryModle() # historyModel클래스생성
        historyId = self.getHistoryId() #historyID가졍괴
        targetDateString = self.getTargetDate().strttime("%Y-%m-%d") #targetDate문자형태
        processId = self.getProcessId() # processId
        dbName = self.getMediaConfig()['db']['db_name'] # dbName
        db = self.getDB() # db생성
        tableName = self.getDataTableName(customerId)
        rowReport = self.getMediaRowReport()
        mediaCode = self.getMediaCOde()
        if db.checkTable(dbName, tableName) == 0:
            db.execute(rowReport.getCreatetableQuery(tableName))
        # 기존에 생성된 테이블이면 product_type 항목이 있는지 체크후 없다면 컬럼 추가
        if(mediaCode == 8 or mediaCode == 107 or mediaCode == 108 or mediaCode == 109):
            if db.checkColumn(tableName, 'product_type') == 0: # checkColumn는 테이블 컬럼 존재 유무 체크
                db.execute(rowReport.addProdubtTypeColumQuery(tableName)) # 쿼리실행
        db.executeMany(rowReport.getInsertQuery(tableName), processData)# 쿼리실행ㅇ
        self.makeResultReportFile(customerId, customer, advertiserInfo) # t _report_daily 입력부 생성
        if hasKeyword:
            self.makeKeywordFilterFile(customerID, customer) # 매체계정별 디비 -> 키워드리포트 디비대상 생성
        # 입력 전 데이터 수 및 입력 후 데이터 개수 비교
        historyModel.compareRawCount(mediaCode, customer, targetDateString, db, tableName, historyModel, historyId, processId)

    def KakaoKeyWordDatabaseProcess(self, customerId, reportData): # 매체 계정별 디비 입력 처리
        dbName = self.getMediaConfig()['db']['db_name']
        db = self.getDb() # 디비생성
        tableName = self.getDataTableName((str(customerId) + 'keyword'))
        rowReport = self.getMediaRowReport()
        if db.checkTable(dbName, tableName)==0:
            db.execute(rowReport.getCreateKeywordTableQuery(tableName))
        db.executeMany(rowReport.getInsertKeywordQuery(tableName), reportData)
        self.makeKakaoKeywordFiterFile(customerId)

    def hasDataCheckByCost(self,resultData): # 매체 계정별 리포트 데이ㅣ터 광고 비용 체크 - 휴면 30일 확인용
        totalCost = 0
        if len(resultData) > 0:
            for row in resultData :
                totalCost+=row[14]
        hasData = False
        if totalCost > 0:
            hasData = True
        return hasData

    def outTransferProcess(self,outTransferData=None): #  피이관 계정 데이터 처리
        if self.getManagementUpdateCheck() == False: # media_history , media_management 업데이트 체크
            return
        #피이관 일자
        outDateString = self.getHelper().getBeforeDate(1,self.getHelper().getNowDate()).strftime('%Y-%m-%d')
        if outTransferData is None:
            outTranferData = self.outTransferData
        managementModel = self.getManagementModl()
        managementModel.outTransferProcess(outTransferData, outDateString)
        self.outTransfer30CostUpdate(outTransferData) #  #피이관 30일 광고비 정보 업데이트

    def outTransfer30CostUpdate(self,outTransferData): #피이관 30일 광고비 정보 업데이트
        if self.getManagementUpdateCheck() == False: # media_history , media_management 업데이트 체크
            return
        if len(outTransferData) == 0:
            return
        db = self.getDefaultDb() # db생성
        mediaCode = self.getMediaCode() # 매체코드생성
        targetDate = self.getTargetDate() # 타겟데이트생성
        startDate = self.getHelper().getBeforeDate(31,targetDate) # startdate생성
        matchingIds = []
        for matchingId in outTranferData.keys(): # 피이관데이터개수만큼
            matchingIds.append(matchingId)
        db.execute("""
        insert into t_media_out_cost(media_code, matching_id, out_date, cost)
        select media_code,matching_id,%(target_date)s,CAST(sum(cost) as SIGNED ) from t_report_daily
        where media_code=%(media_code)s and matching_id in %(matching_ids)s and pay_date >= %(start_date)s
        and pay_date < %(target_date)s group by media_code,matching_id
        """,{
            'media_code':mediaCode,
            'matching_ids':tuple(matchingIds),
            'startDate':startDate.strftime('%Y-%m-%d'),
            'target_date':targetDate.strftime('%Y-%m-%d')
        })

    def bulkInTransferProccess(self,inTransferAdvertiser, inTransferHistory, managementModel): #  매체별 이관 계정 묶음 처리
        if self.getManagementUpdateCheck() == False: # media_history , media_management 업데이트 체크
            return
        managementModel.bulkInTransferProcess(InTransferAdvertiser, InTranferHistory) # 이관 묶음 처리

    def leftAccountsProcess(self): # 매체별 피이관 X 데이터 X 계정 처리
        if self.getManagementUpdateCheck() == False:
            return
        helper = self.getHelper() # 공통헬퍼클래스
        managementModel = self.getManagementModel()  # shareDb true - 싱글 처리 , false - 병렬 처리  return self.managementModel
        managementModel.leftAccountsProcess(self.getMediaCode(),self.getMediaConfig()['m_nm'],self.getDefaultDb(),helper())# 피이관 X , 데이터 X 데이터 처리

    def getManagementUpdateCheck(self):
        """
        media_history , media_management 업데이트 체크
        :return: bool
        """
        return self.managementUpdateCheck

    def getMediaRowReprot(self):
        """ 매체별 계정 디비 CREATE,INSERT QUERY CLASS """
        return ""
    def makeResultReportFile(self,customerID,customer, advertiserInfo):
        """ 매체 계정별 디비 -> 리포트 디비 대상 생성 """
        pass
    def makeKeywordFilterFile(self, customerId, customer):
        """ 매체계정별 디비 -> 키워드리포트 디비대상 생성
        t_keyword_filter_daily ,t_media_keyword_count 테이블 입력 대상 추출
        """
        pass
    def makeKakaoKeywordFilterFile(self, customerId):
        """ 카카오키워드 리포트 디비대상 생성
        t_keyword_filter_daily ,t_media_keyword_count 테이블 입력 대상 추출
        """
        pass    
    def getConfig(self):
        """ Config 객체 반환 """
        return self.config
    def getMediaApi(self):
        """ 매체별 API 객체 반환 """
        return self.mediaApi
    def getMediaConfig(self):
        """ 처리중 PROCCESS CONFIG DICT 반환 """
        return self.getConfig().getAllConfig()[self.processName]
    def getTargetDate(self):
        """ 처리 날짜 반환 """
        return self.targetDate
    def getHelper(self):
        """ Helper Class 반환 """
        return self.helper
    def getDb(self):
        """ 처리중 매체 DB 반환 """
        if self.db is None:
            db = Db()
            if self.processName is not None:
                dbName = self.getMediaConfig()['db']['db_name']
                db.setDb(dbName)
            self.db = db
        return self.db
    def getRmsDb(self):
        """ RMS DB 반환 """
        if self.rmsDb is None:
            try:
                db = Db('rms')
                self.rmsDb = Db
            except Exception as e:
                self.rmsDb = False
            print(e)
        return self.rmsDb
    def getDefaultDb(self):
        """ HM DB 반환 """
        if self.defaultDb is None:
            db = Db()
            self.defaultDb = Db
        return self.defaultDb
    def getDevDb(self):
        """ 개발 DB 설정시 개발 DB 반환 """
        if self.devDb is None:
            db = Db('dev')
            self.devDb = Db
        return self.devDb
    def getLiveDb(self):
        if self.liveDb is None:
            db = Db('live')
            self.liveDb = Db
        return self.liveDb
    def getDataTableName(self,customerId):
        """ 매체별 계정별 DB TABLE NAME """
        processName = self.processName # 프로세스 이름에 google이 들어가면 해당 프로세스 이름 google로 변경
        if(self.procesName.find('google') > -1):
            processName = self.processName.replace(self.processName, 'google')
        return "t_{}_{}".format(processName, customerID)
    def getHistoryModel(self):
        """ HISTORY MODEL CLASS 반환 HISTORY LOG 관련 """
        if self.historyModel is None:
            self.historyModel = history.HistoryModle()
        return self.historyModel
    def getMediaCode(self):
        """ HM MEDIA CODE 반환 """
        if self.mediaCode is None:
            self.mediaCode = self.getHistoryModel().getMediaCode(self.getMediConfig()['name_kr'])
        return self.mediaCOde
    def getHistoryID(self):
        """ 매체 계정 별 history id 반환 """
        return self.historyId
    def closeHistory(self):
        """ HISTORY MODEL 자원 반환 """
        self.historyModel = None
    def closeManagement(self):
        """ MANAGEMENT MODEL 자원 반환 """
        self.managenemtModel=None
    def getReportModel(self):
        """ REPORT MODEL 반환 - DB INSERT 및 UPDATE QUERY 관리 """
        if self.reportModel is None:
            self.reportModel = report.reportModel(self.getDB())
        return self.reportModel