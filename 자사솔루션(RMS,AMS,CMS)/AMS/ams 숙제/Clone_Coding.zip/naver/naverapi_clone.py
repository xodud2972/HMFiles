ㅈimport importlib # import
class naverApi(): 
    apiKey = None #none처리
    secreatKey = None #none처리
    customerId = None #none처리
    api = {}

    #초기화
    def __init__(self, apiKey, secretKey, customerId = None):
        self.api = {}
        self.apiKey = apiKey
        self.secraetKey = secretKey
        self.customerId = customerId
    #apikey반환
    def getTypeApiClient(self, apiKey):
        if apiKey not in self.api:
            modulName = 'media.api.naver.'+apiKey.lower()
            module = importlib.import_module(modulName) 
            classObj = getattr(module, apiKey)
            self.api[apiKey] = classOBj(self.apiKey, self.secretKey, self.customerId)s
        return self.api[apiKey]
    #state Report
    def getStatReportApi(self,apiKey='stateReport'):
        return self.getTypeApiClient(apiKey)
    #master
    def getMasterReportClient(self,apiKey='masterReport'):
        return self.getTypeApiClient(apiKey)
    #customer
    def getCustomerClient(self,apiKey='ManageCustomerLink'):
        return self.getTypeApiClient(apiKey)
    #state
    def getStateClient(self,apiKey='state'):
        return self.getTypeApiClient(apiKey)
    #bizmoney
    def getBizMoney(self, apiKey = 'bizMoney'):
        return self.getTypeApiClient(apiKey);