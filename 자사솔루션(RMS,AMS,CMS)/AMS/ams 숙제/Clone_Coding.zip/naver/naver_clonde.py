from media.models.database.abstract import Abstract
class Naver(Abstract):
    # 테이블생성 함수
    def getCreateTableQuery(self,tableNm):
        createQuery = """
        CREATE TABLE `{}` (
        `increment_id`          INT(11)         NOT NULL AUTO_INCREMENT COMMENT '자동증가ID',
        `pay_date`              DATE            NOT NULL                COMMENT '날짜' COLLATE 'utf8mb4_unicode_ci',
        `advertiser_id`         VARCHAR (50)    NOT NULL DEFAULT '0'    COMMENT '광고주ID', 
        `advertiser_login_id`   VARCHAR(50)     NOT NULL DEFAULT '0'    COMMENT '광고주명'  COLATE 'utf8mb4_unicode_ci4', 
        `campaign_id`           VARCHR(100)     NULL DEFAULT NULL       COMMENT '캠페인 ID' COLLATE 'utf8mb4_unicode_ci', 
        `campaign`              VARCHAR(100)    NULL DEFAULT NULL       COMMENT '캠페인명' COLLATE 'utf8mb4_unicode_ci', 
        `campaign_Type`         INT(2)          NULL DEFAULT NULL       COMMENT '상품타입', 
        `group_id`              VARCHAR(100)    NULL DEFAULT NULL       COMMENT '그룹 ID' COLLATE 'utf8mb4_unicode_ci', 
        `group`                 VARCHAR(100)    NULL DEFAULT NULL       COMMENT '그룹 명' COLLATE 'utf8mb4_unicode_ci', 
        `keyword_id`            VARCHAR(100)    NULL DEFAULT NULL       COMMENT '키워드 ID' COLLATE 'utf8mb4_unicode_ci', 
        `keyword`               VARCHAR(100)    NULL DEFAULT NULL       COMMENT '키워드' COLLATE 'utf8mb4_unicode_ci', 
        `ad_Id`                 VARCHAR(100)    NULL DEFAULT NULL       COMMENT '소재 ID' COLLATE 'utf8mb4_unicode_ci', 
        `business_channel_id`    VARCHAR(100)    NULL DEFAULT NULL       COMMENT '비즈니스 채널 ID' COLLATE 'utf8mb4_unicode_ci', 
        `media_code`            VARCHAR(10)     NULL DEFAULT NULL       COMMENT '서과 발생 매체 ID' COLLATE 'utf8mb4_unicode_ci', 
        `pc_Mobile_Type`        VARCHAR(10)     NULL DEFAULT NULL       COMMENT '노출 발생한 PC 모바일 타입' COLLATE 'utf8mb4_unicode_ci', 
        `impression_cnt`        INT(11)         NULL DEFAULT NULL       COMMENT '노출수', 
        `click_cnt`             INT(11)         NULL DEFAULT NULL       COMMENT '클릭수', 
        `cost`                  DECIMAL(10,2)   NULL DEFAULT NULL       COMMENT '광고비', 
        `rank`                  INT(11)         NULL DEFAULT NULL       COMMENT '노출 순위 합', 
        `view_Count`            INT(11)         NULL DEFAULT NULL       COMMENT '과금되는 동영상 조회 수', 
        `conversion_cnt`        INT(11)         NULL DEFAULT NULL       COMMENT '전환 수', 
        `conversion_amnt`       INT(11)         NULL DEFAULT NULL       COMMENT '전환 매출', 
        PRIMARY KEY (`increment_id`), 
        INDEX `pay_date` (`pay_date`), 
        INDEX `campaign` (`campaign`), 
        INDEX `group` (`group`), 
        INDEX `keyword` (`keyword`) 
        ) 
        COLLATE='utf8mb4_unicode_ci' 
        ENGINE=InnoDb;
        """.format(tableNm)
        return createQuery
    # 데이터 insert함수
    def getInsertQuery(self,tableNm):
        insertQuery = """
        INSERT INTO  {}(pay_date, advertiser_id, advertiser_login_id, campaign_id, campaign, campaign_type,
        group_id, `group`, keyword_id, keyword, ad_id, business_chnnel_id, media_code, pc_mobile_type,
        impression_cnt, click_cnt, cost, `rank`, conversion_cnt, conversion_amnt)
        VALUES (%s, %s, %s, %s, %s,%s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """.format(tableNm)
        return insertQuery