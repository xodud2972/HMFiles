from media.process.abstract.abstractprocess import AbstractProcess
class MultiProcess(AbstractProcess):
    #초기화
    def _init__(self, targetDate=None, processId=None, managementUpdateCheck=False):
        super().__init__(targetDate, proccessId,managementUpdateCheck)
        # 멀티 프로세스 자원 반환 공통
    def getTargetList(self):
        result = super().getTargetList() # 부모파일(abstract)의 getTargetList를 실행시켜서 result로 저장
        self.closeResource()
        return result
    def execute(self,advertiser,shareData=None):
        result = super().execute(advertiser,shareData) # 부모파일(abstract)의 execute 실행시켜서 result로 저장
        self.closeRseource()
        return result