from media.helpers.advertiser.status.switch import StatusSwitch
from media.db import Db
from media.helpers.helper import Helper
from datetime import timedelta,date
import json, sys

class Management(): # 멀티 프로세스용 MANAGEMENT MODEL
    #초기화
    def __init__(self, targetDate, media, updateCheck, helper = None, db = None, defaultDb = None):
        self.targetDate = targetDate
        self.media = media
        self.db = db
        self.defaultDb = defaultDb
        self.helper = helper
        self.mediaLastchangeHistory,self.advertiserStatushelper = [None,None]
        self.updateCheck = updateChck
    # Helper Class 반환
    def getHelper(self): 
        if self.helper is None: #헬퍼가 없으면
            self.helper = Helper() #헬퍼생성
        return self.helper #헬퍼반환
    def getTargetDate(self): # 처리 일자 반환 함수
        return self.targetDate
    def getAdvertiserStatusHelper(self): # 상태 이력 점검 Hepler 반환
        if self.advertiserStatuHelper is None: # advertiserStatuHelper가 없으면
            self.advertiserStatusHelper = StatusSwitch(self.getDb(),self.getTargetDate())
        return self.advertiserStatusHelper
    def outTransferProcess(self,outTransferData,outDate): # 피이관 처리 함수
        """
        피이관 처리 함수
        :param outTransferData: {}
        :param outDate: str
        :return:
        """
        if self.getUpdateCheck() != True: # getUpdateCheck함수는 self.updateCheck를 리턴
            return
        statusHelper = self.getAdvertiserStatusHelper() #  상태 이력 점검 Hepler 반환
        outTrasferBindData = {
            'advertiser':[],
            'history_update':[],
            'history_insert':[]
        }
        outTransferStatus = statusHelper.getStatusConfigVal(statusHelper.OUT_TRANGSFER) # 상태 코드 가져오기
        for matchingId,row in outTransferData.items(): # 피이관 데이터 수 만큼 반복
            """ 피이관 체크 """
            if row['status'] != statusHelper.getStatusConfigValue(statusHelper.OUT_TRANSFER): # 상태 코드 가져오기
                outTransferBindData['advertiser'].append(row['advertiser_id'])
                outTransferBindData['history_update'].append([
                    row['increment_id']
                ])
                outTransferBindData['history_insert'].append([
                    row['advertiser_id'],
                    row['media_code'],
                    row['matching_id'],
                    row['em_seq'],
                    outDate,
                    outTransferStatus
                ])
        if len(outTransferBindData) > 0:
            self.outTransferUpdate(outTransferBindData)
    def outTransferUpdate(self,data):
        """ 피이관DB UPDATE및INSERT """
        if self.getUpdateCheck() != True: # getUpdateCheck함수는 self.updateCheck를 리턴
            return 
        defaultDb = self.getDefaultDB() # 디비생성
        helper = self.getHelper() # 헬퍼생성
        if len(data['advertiser']) == 0:
            return
        statusSwitchHelper = self.getAdvertiserStatusHelper() # # 상태 이력 점검 Hepler 반환
        defaultDb.execute("""update t_advertiser_media_management set current_status=%(status)s where increment_id in %(ids)""",{
            'status':statusSwitchHelper.getStatusConfigValue(StatusSwitch.OUT_TRANSFER), # 상태 코드 가져오기
            'id':tuple(data['advertiser'])
        })
        defaultDb.execute("""
        update t_advertiser_media_history set end_date=%(end_date)s where increment_id in %(ids)s
        """,{
            'end_Date':helper.getBeforeDate(1,helper.getNowDate()).strtfime('%Y-%m-%d'),
            'id':tuple(data['history_update'])
        })
        defaultDb.executeMany("""
        insert into t_advertiser_media_history(advertiser_id,media_code,matching_id, em_seq, start_date, status)
        values (%s ,%s ,%s ,%s ,%s ,%s)
        """,data['history_insert'])
    def lastAccountsProcess(self,mediaCode,mNm,defaultDb,helper):
        """ 피이관 X , 데이터 X 데이터 처리 """
        if self.getUpdateCheck() != True:  # getUpdateCheck함수는 self.updateCheck를 리턴
            return
        leftAccounts = self.getMediaLastChangeHistory(mediaCode) # 매체별 광고주 최신 상태 변경 이력 값 가져오기
        lastMatchingInfo = helper.getLastMatchingDataByNm(mNm, defaultDb) #  mNm 별 t_media_mapping_latest 테이블 정보 가져오기
        outTransferValue = self.getAdvertiserStatusHelper().getStatusConfigValue(StatusSwitch.OUT_TRANSFER) #상태 코드 가져오기
        for leftAccount in leftAccounts: # 매체별 광고주 최신 상태 변경 이력 값 개수만큼 반복
            account = leftAccounts[leftAccount]
            beforeData = leftAccounts[leftAccount].copy()
            if beforeData['status'] == outTransferValue:
                continue
            if leftAccount in lastMatchaingInfo:
                account['em_seq'] = lastMatchingInfo[leftAccount]['em_seq']
            self.updateAdvertiserStatusHistory(mediaCode, account, False, beforeData,True) # MANAGEMENT,HISTORY 상태 이력 업데이트 처리
    def getMediaLastChangeHistory(self,mediaCode):
        """
        매체별 광고주 최신 상태 변경 이력 값 가져오기
        :param mediaCode:
        :return:
        """
        if self.mediaLastChangeHistory is None:
            defaultDb = self.getDefaultDb() # 디비생성
            result = defaultDb.fetchAll("""
            select tamh.*,tamm.m_sub_id,min(tamh.start_date) as advertiser_start from (
                                                                         select * from t_advertiser_media_history where media_code=%s  order by start_date desc,created_at desc
                                                                         limit 100000000000000
                                                                     ) as tamh
                                                                         left join t_advertiser_media_management as tamm on tamh.advertiser_id=tamm.increment_id
            group by advertiser_id
                    """, [mediaCode], cursor='dict')
            bindData = {}
            for row in result:
                bindData[row['matching_id']] = row
            self.mediaLastChangeHistory = bindData
        return self.mediaLastChangeHistory
    def inTransferProccess(self,mediaCode,dataTableNm,matchingId,startDate,advertiserInfo,matchingData,companyNo=None,additionalData={}):
        """ 이관 처리 """
        if self.getUpdateCheck() != True: # getUpdateCheck함수는 self.updateCheck를 리턴
            return
        defaultDb = self.getDefaultDb()
        statusSwitcher = self.getAdvertiserStatusHelper() # 상태 이력 점검 Hepler 반환
        em_seq, cs_seq, csType, division, team = list(matchingData)
        defaultDb.execute("""
        insert into t_advertiser_media_management(media_code, matching_id, table_name, cs_seq, cs_type, current_status, m_id, m_sub_id, advertiser_name,company_no,additional_data)
        values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,[
            mediaCode,matchingId,dataTableNm,csSeq,csType,
            statusSwitcher.getStatusConfigValue(statusSwitcher.IN_TRANSFER), # 상태 코드 가져오기
            advertiserInfo['main_id'],advertiserInfo['sub_id'],advertiserInfo['name'],companyNo,
            json.dumps(additionalData)
        ])
        advertiserID = defaultDb.fetchOne("""
        select increment_id from t_advertiser_media_management where media_code=%s and matching_id=%s
        """,[mediaCode,matchingId])
        defaultDb.execute("""
        insert into t_advertiser_media_history(advertiser_id, media_code, matching_id, em_seq, start_Date, status)
        values(%s, %s, %s, %s ,%s ,%s)
        """,[
            advertiserId,mediaCode,matchingId,emSeq,startDate,
            statusSwitcher.getStatusConfigValue(statusSwitcher.IN_TRANSFER) # 상태 코드 가져오기
        ])
    def bulkinTransferProcess(self,managementData,historyData):
        """ 이관 묶음 처리 """
        if self.getUpdateCheck() != True:
            return
        defaultDB = self.getDefaultDb() # 디비생성
        statusSwitcher = self.getAdvertiserStatusHelper()# 상태 이력 점검 Hepler 반환
        defaultDb.executeMany("""
        insert into t_advertiser_media_management(media_code, matching_id, table_name, cs_seq, cs_type, current_status, m_id, m_sub_id, advertiser_name,company_no,additional_data)
        values(%s ,%s ,%s ,%s ,%s ,{} ,%s, %s ,%s ,%s ,%s)
        """.format(statusSwitcher.getStatusConfigValue(statusSwitcher.IN_TRANSFER)),managenemntData) # 상태 코드 가져오기
        defaultDb.executeMany("""
        insert into t_advertiser_media_history(advertiser_id, media_code, matching_id, em_seq, start_date, status)
        values((select increment_id from t_advertiser_media_management where media_code = %s and matching_id = %s limit 1),%s ,%s ,%s ,%s ,{})
        """.format(statusSwitcher.getStatusConfigValue(statusSwitcher.IN_TRANSFER)),historyData) # 상태 코드 가져오기
    def updateAdvertiserStatusHistory(self,mediaCode,advertiserInfo,hasData,beforeData=None,isLeft=False):
        """ MANAGEMENT,HISTORY 상태 이력 업데이트 처리 """
        if self.getUpdateCheck() != True:
            return False
        result = False
        advertiserId = None
        status = None
        advertiserStart = None
        matchingId = advertiserInfo['matching_id']
        emSeq = advertiserInfo['em_seq']
        """ beofre data가 없을 경우 기존의 등록된 데이터 중 가장 최신 데이터 가져오기 """
        if beforeData is None:
            lastHistoryData = self.getMediaLastChageHistory(mediaCode) 
            if matchingId in lastHistoryData: # 광고주 최신 상태 변경 이력 값 개수만큼 반복
                beforeData = lastHistoryData[matchingId]
        if beforeData is not None: # None이 아니면
            status = beforeData['status']
            advertiserId = beforeData['advertiser_id']
            advertiserStart = beforeData['advertiser_start']
        if advertiserId is not None: # None아니면
            result = self.updateManagenent({
                'media_code'        : mediaCode,
                'current_status'    : status,
                'current_employee'  : em_Seq,
                'advertiser_id'     : advertiserID,
                'matching_id'       : matchingID,
                'advertiser_start'  : advertiserStart,
                'has_data'          : hasData,
                'is_left'           : isLeft
            },beforeData)
        return result
    def getStatusResult(self,currentData,beforeData):
        """ MANAGEMENT,HISTORY 상태 변경 점검 """
        mediaCode,currentStatus,currentEmployee,advertiserId,matchingId,advertiserStart,hasData,isLeft = [
            currentData['media_code'],currentData['current_status'],
            currentData['current_employee'],currentData['advertiser_id'],
            currentData['matching_id'],currentData['advertiser_start'],
            currentData['has_data'],currentData['is_left']
        ]
        statusSwitcher = self.getAdvertiserStatusHelper() # 상태 이력 점검 Hepler 반환
        updateSkipResult = statusSwitcher.bindreturn(False,False,currentStatus) # RETURN 공통 BINDING 함수
        if currentStatus == statusSwitcher.getStatusConfgValue(statusSwitcher.SLEEP_LESS_THAN_30): # 상태 코드 가져오기
            checkTargetDate = self.getTargetDate()
            if type(checkTargetDate) != date: #타입이 날짜가 아니면
                checkTargetDate = checkTargetDate.date() # 날짜타입으로 변경
            if beforeData['start_date'] = checkTargetDate: 
                return updateSkipResult
        if currentStatus != statusSwitcher.getStatusConfigValue(statusSwitcher.OUT_TRANSFER) and str( 
                beforeData['em_seq']) != str(currentEmployee):
            if beforeData['em_seq'] is None:
                self.getDefaultDb().execute("update t_advertiser_media_history set em_seq = %s where advertiser_id = %s and em_seq is null",
                                            [currentEmployee,beforeData['advertiser_id']])
                statusResult = statusSwitcher.switch(currentStatus, statusValue=currentStatus, matchingId=matchingId,
                                                     advertiserStart=advertiserStart, hasData=hasData, isLeft=isLeft)
            else:
                statusResult = statusSwicher.getInternalTransferData() # 내부이관 update bind
        else:
            # 상태 별 함수 매칭s
            statusResult = statusSwitcher.switch(currentStatus, statusValue=currentStatus, matchingId=matchingId,
                                                 advertiserStart=advertiserStart, hasData=hasData, isLeft=isLeft)
        return statusResult
    def updateManagement(self,currentData,beforeData):
        """ MANAGEMENT,HISTORY 상태 이력 DB 처리 """
        if self.getUpdateCheck() != True:
            return True
        mediaCode,currentStatus,currentEmployee,advertiserId,matchingId,advertiserStart,hasData,isLeft = [
            currentData['media_code'],currentData['current_status'],currentData['current_employee'],currentData['advertiser_id'],
            currentData['matching_id'],currentData['advertiser_start'],currentData['has_data'],currentData['is_left']
        ]
        result = True
        endDate = self.getTargetDate()
        defaultDB= self.getDefaultDb()
        startDate = self.getTargetDate()
        helper = self.getHelper()
        if type(endDate)==type(beforeData['start_date']):
            if endDate < beforeData['start_date']:
                endDate = beforeData['start_date']
        else:
            if endDate.date() < beforeData['start_date']:
                endDate = beforeData['start_date']
        statusResult = self.getStatusResult(currentData,beforeData) #MANAGEMENT,HISTORY 상태 변경 점검
        if statusResult['history_update'] == True and statusResult['status'] == self.getAdvertiserStatusHelper().getStatusConfigValue(
                self.getAdvertiserStatusHelper().SLEEP_LESS_THEN_30):
            before30date = self.getTargetDate() - timedelta(days = 30)
            before60dat = self.getTargetDate()- timedelta(days = 60)
            sleepBeforeCost = self.getDB().fetchOne(
                'select sum(cost) from t_report_daily where pay_date <= %s and pay_date > %s and matching_id = %s', [
                    before30date.strftime('%Y-%m-%d'), before60date, currentData['matching_id']
                ])[0]
            sleepBeforeCost = 0 if sleepBeforeCost is None else sleepBeforeCost
            self.getDefaultDb().execute('insert into t_media_out_cost(media_code,matching_id,out_date,cost) values (%s,%s,%s,%s)'
                                        ,[currentData['media_code'],currentDate['matching_id'],self.getTargetDate().strftime('%Y-%m-%d'),sleepBeforeCost])
        if statusResult['advertiser_update'] == True:
            defaultDb.execute("""
            update t_advertiser_media_management set current_status=%s where increment_id=%s
            """, [statusResult['advertiser_status'], advertiserId])
        if statusResult['history_update'] == True:
            if helper.getYesterdayDate().strftime('%Y-%m-%d') != self.getTargetDate().stftime('%Y-%m-%d'):
                defaultDb.execute("""
                insert into t_advertiser_media_history(advertiser_id, media_code, matching_id, em_seq, start_date,end_date, status)
                values(%s ,%s ,%s ,%s ,%s ,%s ,%s)
                """, [
                    advertiserId, mediaCode, matchangeId, currentEmployee, startDate.strftime('%Y-%m-%d'),
                    startDate.strftime('%Y-%m-%d'),
                    statusResult['status']
                ])
            else:
                defaultDb.execute("""
                update t_advertiser_media_history set end_date=%s where increment_id=%s
                """, [endDate.strftime('%Y-%m-%d'), beforeData['increment_id']])
                defaultDb.execute("""
                insert into t_advertiser_media_history(advertiser_id, media_code, matching_id, em_seq, start_date, status)
                values(%s,%s,%s,%s,%s,%s)
                """, [
                    advertiserId, mediaCode, matchingId, currentEmployee, startDate.strftime('%Y-%m-%d'),
                    statusResult['status']
                ])
        return result
    def getUpdateCheck(self):
        return self.updateCheck
    def getDb(self):
        if self.db is None:
            self.db = Db()
            self.db.setDB(self.media)
        return self.db
    def getDefaultDb(self):
        if self.defaultDb is None:
            self.defaultDb = DB()
        return self.defaultDb