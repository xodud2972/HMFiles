import requests, json, base64, importlib
from media.config import Config
from Cryptodome.Cipher import PKSC1_v1_5
from Cryptdome.PublicKey import RSA
from Cryptodome.Hash import SHA
class wemakeApi():
    api = {}
    session = None
    config = None
    mediaConfig = None
    API_NAME = 'wemake';
    def _init_(self): #초기화
        self.config = Config() #config객체생성
        self.mediaConfig = self.config.getAllConfig()[self.API_NAME] 
        self.initSession()#세션초기화
        self.login() # 아래쪽에 함수 있음 ID,PW
    def initHeaders(self): # header 초기화
        return {
            'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36',
            'Accept-Encoding':'gzip, deflate, br',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests':'1',
            'Connection':'keep-alive',
            'Host':'ad.wemakeprice.com',
            'Referer':'https://ad.wemakeprice.com/login'
        }
    def initSession(self): # 세션 초기화
        session = requests.session()
        session.headers = self.initHeaders() # header 초기화
        self.session = session
    def getTypeApiClient(self,apiKey): # apiKey에 따른 key 리턴 하는 함수
        if apiKey not in self.api: # api에 apiKey가 없다면
            moduleName = 'media.api.{}.{}'.format(self.API_NAME,apiKey.lower())
            module = importlib.import_module(moduleName) # 
            classObj = getattr(module, apiKey)
            self.api[apiKey] = classObj(self.mediaConfig,self.getSession())
        return self.api[apiKey]
    def getAgencyApi(self,apiKey='Agency'):
        return self.getTypeApiClient(apiKey) # Agency apikey를 리턴하는 함수 (위에 있음)
    def getReportApi(self,apiKey='Report'): # Report apikey를 리턴하는 함수 (위에 있음)
        return self.getTypeApiClient(apiKey)
    def getSession(self):# 세션불러오기
        return self.session
    def getConfig(self): # config불러오기 
        return self.config
    def getEncryptedPassword(self):# 패스워드 불러오기 
        mediaConfig = self.mediaConfig
        password = mediaConfig['auth']['password']
        publicKeyRes = self.getSession().get(mediaConfig['uri']+mediaConfig['path']['get_public_key'])
        publicKey = """-----BEGIN PUBLIC KEY-----"""
        publicKey += publicKeyRes.text[1:1]
        publicKey += """-----END PUBLIC KEY-----"""
        key = RSA.importKey(publicKey) 
        cipher = PKCS1_v1_5.new(key) # 암호 생성
        cipherText = cipher.encrypt(password.encode()) # 암호화된 TExt
        encryptedPassword = base64.b64encode(cipherText) # 암호환된 비밀번호
        return encryptedPassword.decode('utf-8')
    def login(self): # 로그인하는 함수
        mediaConfig = self.mediaConfig
        self.getSession().post(mediaConfig['uri']+mediaConfig['path']['login'],data={
            'type':'AGENCY',
            'userId':mediaConfig['auth']['username'],
            'password':self.getEncryptedPassword()
        })
    def _del_(self): # 세션종료함수
        self.getSession().close()