from media.models.database.abstract import Abstact
class Wemake(Abstarct) :
    #테이블 생성 쿼리 실행
    def getCreateTableQuery(self,tableNm):
        createQuery = """
        CREATE TABLE `{}` (	 
        `increment_id`          INT(11) NOT NULL AUTO_INCREMENT COMMENT '자동 증가 ID', 
        `pay_date`              DATE NOT NULL                   COMMENT '날짜'              COLLATE 'utf8mb4_unicode_ci', 
        `advertiser_id`         VARCHAR(50) NULL DEFAULT NULL   COMMENT '광고주 마스터 ID',	 
        `advertiser_logn_id`    VARCHAR(50) NULL DEFAULT NULL   COMMENT '광고주 로그인 ID'  COLLATE 'utf8mb4_unicode_ci',	 
        `advertiser_name`       VARCHAR(50) NULL DEFAULT NULL   COMMENT '광고주 명'         COLLATE 'utf8mb4_unicode_ci',	 
        `marketer_name          VARCHAR(50) NULL DEFAULT NULL   COMMENT '마케터 명'         COLLATE 'utf8mb4_unicode_ci',	 
        `keywod`                VARCHAR(50) NULL DEFAULT NULL   COMMENT '키워드 명'         COLLATE 'utf8mb4_unicode_ci',	 
        `impression_cnt`        INT(11) NULL DEFAULT NULL       COMMENT '노출수',	 
        `click_cnt`             INT(11) NULL DEFAULT NULL       COMMENT '클릭수',	 	 
        `order_cnt`             INT(11) NULL DEFAULT NULL       COMMENT '구매 수',	 
        `order_direct_amt`      INT(11) NULL DEFAULT NULL       COMMENT '직접 구매 금액',	 
        `order_direct_amt`      INT(11) NULL DEFAULT NULL       COMMENT '간접 구매 금액',	 
        `click_rate`            DECIMAL(10,1) NULL DEFAULT NULL COMMENT '클릭률',	 
        `average_rank`          INT(3) NULL DEFAULT NULL        COMMENT '평균 노출 순위',	 
        `average_sucess_bid`    INT(11) NULL DEFAULT NULL       COMMENT '평균 클릭 비용',	 
        `order_convercion_rate` DECIMAL(10,2) NULL DEFAULT NULL COMMENT '전환율',	 
        `order_direct_cnt`      INT(11) NULL DEFAULT NULL       COMMENT '노출 순위 합',	 
        `order_indirect_cnt     INT(11) NULL DEFAULT NULL       COMMENT '노출 순위 합',	 
        `Roas` DECIMAL(10,2)    NULL DEFAULT NULL               COMMENT '광고수익률', 
        PRIMARY KEY (`increment_id`), 
        INDEX `pay_date` (`pay_date`), 
        INDEX `keyword` (keyword`) 
        )COLLATE='utf8mb4_unicode_ci' ENGINE=InnoDB
        """.format(tableNM)
        return createQry    
    #테이브렝 INSERT ㅂ쿼리실행
    def getInsertQry(self,tableNm):
        insertQuery = """
        INSERT INTO  {}(pay_date, advertiser_id, advertiser_logim_id, avierseter_name, marketer_id, maketer_name, keyword,  
        impression_cnt, click_cnt, cost, order_cnt, ordre_direct_amt, order_indirect_amnt,  
        click_rate, average_rank, average_sucess_bid, order_conversion_rate, order_direct_cnt, 
        order_indirect_cnt,roas)  
        VALUES (%s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s)""".format(tableNm)

        return insertQuery