from media.api.wemaekapi import WemakeApi as MediApi
from media.prcess.abstract.multiproecss import MultiProcess as AbstractPRocess
from media.models.database.wemake import Wemake as MediaRowReport
import datetime,html
class Wemake(AbstractProcess):
    processName = 'wemake' # wemake
    # 초기화
    def __init__(self,targetDate=None, processId=None, managementUpdateCheck=False):
        super().__init__(targetDate,processId,managementUpdateCheck)
        self.mediaApi = MediaApi()
    def getMediaRowReport(self): # 매체별 계정 디비 CREATE,INSERT QUERY CLASS
        return MediaRowReport()
    def _getTargetList(self): # 계정리스트 (병렬처리)
        mediaApi = self.getMediApi() #mediaApi
        agencyApi = mediaApi.getAgencyApi() #agencyApi 가져오기
        page=0 
        size=1000
        targetList = [] #targetList        
        helpr = self.getHelper() # helper 클래스 생성
        todayDate = self.getHelper().getNowDate() # 오늘 날짜
        managementModel = self.getManagementModel(False) # false = 병렬처리
        # 매체코드에따른 광고주 최신 상태 변경 이력 값 가져오기
        lastHistoryData = managementModel.getMediaLastChageHistor(self.getMediaCode())
        inTransferAdvetiser = [] # 이관
        inTransferHistory = []
        mediaCode = self.getMediaCode() # 매체코드 가져오기
        totalAdvertiserData = helper.getTotalAdvertisreData(self.getRmsDb()) # t_customer 정보
        # getLastMatchingDataByMNm 함수는 매체별로 t_media_mapping_latest에 있는 정보 가져오기
        lastMatchingInfo = helper.getLastMatchingDataByMn(self.getMediaConfig['m_nm'],self.getDefaultDb())
        while True: # 무한루프
            partnerList = agencyApi.getPartnerList(page, size)
            if partnerList == False: # partnerList가 없으면 오류 발생
                raise Exception("GET PARTNER LIST FAIL MORE THEN 34")
            for account in partnerList['rows']: # partnerList에 rows 수 만큼 반복
                matchingId = account['partnerId']
                account['partnerName'] = html.unescape(account['partnerName'])
                acount['matching_id'] = matchingId
                if matchingId not in lastHistoryData: # 신규이면
                    emSeq, csSeq, csType, division, team = [None, None, None, None, None] #none처리
                    #getMatchinginfo함수는 매체별로 matching id 로 매핑된 emSeq,csSeq,csNm,csType,division,team,csTypeNew1,csTypeNew2 정보 가져오는 함수
                    emSeq ,csSeq, csNm, csType, division,team, csTypeNew1, csTypeNew2 = helper.getMatchingInfo(self.processName, matchingId, self.getDefaultDb(), self.getRmsDb())
                    inTransferAdvertiser.append([
                        mediaCode, matchingId, self.getDataTableName(account['partnerId']), csSeq, csType
                        matchingId, account['partnerId'], acount['partnerName'], account['businessRgNo'].replace('-',''),
                        self.dataToJSON(account)
                    ])
                    inTransferHistory.append([
                        mediaCode, matchingId, mediaCode, matchingId, emSeq,
                        datetime.fromtimestamp(account['createTime'] / 1000).strtfime('%Y-%m-%d')
                    ])
                    account['beforeData']=None
                else:
                    account['beforeData']=lastHistoryData[matchingId]
                    lastHistoryData.pop(matchingId)
                targetList.append(account)
            if page == int(partnerList['total']/size):
                break
                page=1
        # 매체별로 이관계정을 묶음처리한다 (management.py에 있음)
        self.bulkInTransferProcess(inTransferAdvertiser, inTransferHistory, managementModel)
        # 매체별로 피이관 계정을 묶음처리한다. (management.py에 있음)
        self.outTransferProcess(lastHistoryData)
        targetDateStrng = self.getTargetDate().strftime('%Y-%m-%d') # 문자로 변경
        self.getHistoryModel().insertAdvertiserTodayTarget(targetDateString, self.getProcessId() ,self.getMediaCode(),
                                                           targetList, 'partnerUserId','createTime',True)
        return targetList # 타겟리스트 반환
    def _execute(self, advertiserInfo, shareData = None): #실행부
        helper = self.getHelper() # 헬퍼생성
        startedDate = helper.getNowDateString() # 시작날짜
        historModel = self.getHistoryModel() # historyModel
        targetDate = self.getTargetDate() #targetDate
        customer = advertiserInfo['partneUserId'] #customer
        self.loadHistoryId(customer) 
        historyId = self.getHistoryId() #historyId
        try:
            mediaApi = self.getMediaApi()
            reportApi = mediaApi.getReportApi()
            customerId = advertiserInfo['partnerId']
            reportData = reportApi.getKeywrdReport(customerId,targetDate.strftime('%Y-%m-%d'))
            aiPlusReport = reportApi.getDateReportAiPlus(customerId, targetDate.stftime('%Y -%m-%m'))
            bindingData = self.bindingData(advertiserInfo,reportData)
            if len(bindData) > 0 or len(PlusReport) > 0:
                endDate = self.helper.getNowDateString()
                historyModel.updateAdvertisrData(historyId, startedDate, endDate, len(bindingData)) # 광고주 히스토리 정보 업데이트
                self.databaseProccess(customerId,customer,bindingData,advertiserInfo) # DB처리
            else:
                if advertiserInfo['beforeData'] is not None:
                    emSeq, csSeq, csNm, csType, division, team, csTypeNew1, csTypeNew2 = self.getMatchingInfo(customer)
                    advertiserInfo['em_seq'] = emSeq
                    hasData = False
                    managementModel = self.getManagementModel()
                     # MANAGEMENT,HISTORY의 상태이력을 업데이트
                    managementModel.updateAdvertiserStatusHistory(self.getMediaCode(), advertisserInfo, hasData, advertiserInfo['beforeData'])
        except Exception as e: #에러발생시
            import traceback
            #에러 history테이블에 넣어주기
            historyModel.insertHistoryMessage(historyId, traceback.format_exc())
        return True
    def makeResultReportFile(self, customerId, customer, advertiserInfo): # 리포트파일 만드는 함수
        helper = self.getHelper() # 헬퍼생성
        targetDateString = self.getTargetDate().strftime("%Y-%m-%d")
        dataTablenm = self.getDataTableName(customerID)
        emSeq, csSeq, csNm, csType, division, team,csTypeNew1,csTypeNew2 = self.getMatchingInfo(customer)
        mediaApi = self.getMediaPi()
        reportApi = mediaApi.getReportApi()
        dateSummaryRepoert = reportApi.getDateReport(customerId,targetDateString)
        dateAiPlusSummaryReport = reportApi.getDateReportPlus(customerId,targetDateString)
        resultData = []
        mediaCode = self.getMediaCode()
        if len(dateSummaryReport) > 0: 
            resultData.append([targetDateString,mediaCode,str(emSeq), str(division), str(team), str(csSeq), str(csNm), str(csType),
                               str(csTypeNew1),str(csTypeNew2),customer,'target_click',
                      dateSummaryReport[0]['pvCount'],round(dateSummaryReport[0]['clickCount']),round(dateSummaryReport[0]['totalCost']),
                      dateSummaryReport[0]['soldCountAll'],int(dateSummaryReport[0]['gmvDirect'])+int(dateSummaryReport[0]['gmvIndirect'])])
        if len(dateAiPlusSummaryReport) > 0:
            resultData.append(
                [targetDateString,mediaCode, str(emSeq), str(division), str(team), str(csSeq), str(csNm), str(csType),
                 str(csTypeNew1),str(csTypeNew2),customer, 'ai_plus',
                 dateAiPlusSummaryReport[0]['pv'], round(dateAiPlusSummaryReport[0]['click']), round(dateAiPlusSummaryReport[0]['adCost']),
                 dateAiPlusSummaryReport[0]['soldCountAll'], int(dateAiPlusSummaryReport[0]['gmvDirect']) + int(dateAiPlusSummaryReport[0]['gmvIndirect'])])
        if advertiserInfo['beforeData'] is not None ;
            advertiserInfo['em_seq'] = 
            # 매체 계정별 리포트 데이터 광고 비용 체크 - 휴면 30일 확인용
            hasData = self.hasDataCheckByvCost(resultData)
            managementModel = self.getManagemntModel()
            # MANAGEMENT,HISTORY 상태 이력 업데이트 처리
            managementModel.updateAdvertiserStatusHistory(mediaCode, advertiserInfo, hasData,advertiserInfo['beforeData'])
        # 폴더 유무 점검 없을시 생성
        helper.checkDSIr(helper.realationJoinPath('file',self.processNaem, 'report', 'result'))
        # CSV 파일 입력 후 저장
        helper.writeCsvFileData(helper.relationJoinPath('file',self.processName,'report','result',dataTableNm),resultData)
    def makeKeywordFilterFile(self, customerId, customer): ## 리포트 키워드 필터 파일생성
        mediaDb = self.getDb()
        helper = self.getHleper()
        targetDateString = self.getTargetDate().strftime("%Y-%m-%d")
        dataTableNm = self.getDataTableName(customerId)
        emSeq, csSeq, csNm, csType, division, team,csTypeNew1,csTypeNew2 = self.getMatchingInfo(customerr)
        # resultData
        resultData = mediaDb.fetchAll("""
        SELECT '{}','{}','{}','{}','{}','{}','{}', '{}','{}', '{}', keyword, CAST(SUM(impression_cnt) AS SIGNED) AS impression_cnt, CAST(SUM(click_cnt) AS SIGNED) AS click_cnt,
        CAST(SUM(cost) AS SIGNED) AS cost, IF(sum(click_cnt)>0 && SUM(impression_cnt)>0 ,ROUND((sum(click_cnt)/sum(impression_cnt)),2),0) AS ctr,
        CAST(sum(order_cnt) as SIGNED ) as conversion_cnt,
        CAST(sum(order_direct_amnt) as SIGNED ) + CAST(sum(order_indirect_amnt) as SIGNED ) as conversion_amnt FROM {} 
        WHERE pay_date='{}' GROUP BY pay_date, keyword HAVING (impression_cnt >=100 or click_cnt>=5 or cost>=10000)
        """.format(targetDateString, emSeq, division, team, csSeq, csType,csTypeNew1,csTypeNew2, customer,self.processName,dataTableNm, targetDateString))
        if resultData: # resultData있으면
            logData = mediaDb.fetchAll("""
            SELECT '{}', '{}', '{}', '{}', 'filter', count(keyword) FROM 
            (SELECT pay_date, CAST(SUM(impression_cnt) AS SIGNED) AS impression_cnt, 
            CAST(SUM(click_cnt) AS SIGNED) AS click_cnt, CAST(SUM(cost) AS SIGNED) AS cost,keyword,
            CAST(sum(order_cnt) as SIGNED ) as conversion_cnt,
            CAST(sum(order_direct_amnt) as SIGNED ) + CAST(sum(order_indirect_amnt) as SIGNED ) as conversion_amnt 
            FROM {} WHERE pay_date='{}' GROUP BY keyword HAVING (impression_cnt >=100 or click_cnt>=5 or cost>=10000)) AS a
            """.format(targetDateString,self.processName, customer,self.processName, dataTableNm, targetDateString))
            # 폴더 유무 점검 없을시 생성
            helper.checkDir(helper.relationJoinPath('file', 'keyword', self.processName, 'fillter', 'log'))
            # CSV 파일 입력 후 저장
            helper.writeCsvFileData(helper.relationJoinPath('file', 'keyword', self.proccessName, 'filter', 'log', dataTableNm),logData)
        # 폴더 유무 점검 없을시 생성
        helper.checkDir(helper.relationJoinPath('file', 'keyword', self.processName, 'fillter', 'result'))
        # CSV 파일 입력 후 저장
        helper.writeCsvFileData(helper.relationJoinPath('file', 'keyword', self.proccessName, 'filter', 'result', dataTableNm),logData)
    def bindingData(self,advertiserInfo,reportData):
        bindingData = []
        targetDate = self.getTargetDate().strftime('%Y-%m-%d')
        for reportRow in reportData:
            rowData = [
                targetDate,
                advertiserInfo['partnerId'],
                advertiserInfo['partnerUserId'],
                advertiserInfo['partnerName'],
                advertiserInfo['marketerId'],
                None if 'marketerName' not in advertiserInfo else advertiserInfo['marketerName'], #advertiserInf에 maketerName이 없으면 None 있으면 advertiserInfo['marketerName']
                reportRow['basis'],
                reportRow['pvCount'],
                reportRow['clickCount'],
                reportRow['totalCost'],
                reportRow['soldCountAll'],
                reportRow['gmvDirect'],
                reportRow['gmvIndirect'],
                reportRow['clickRate'],
                reportRow['averageRank'],
                reportRow['averageSuccessBid'],
                reportRow['conversionRate'],
                reportRow['soldCountIndirect'],
                reportRow['adYieldRate']
            ]
            bindingData.append(rowData)
        return bindingData